Text file: user.py
Latest content with line numbers:
1	from flask_sqlalchemy import SQLAlchemy
2	from datetime import datetime
3	import bcrypt
4	
5	db = SQLAlchemy()
6	
7	class User(db.Model):
8	    __tablename__ = 'users'
9	    
10	    id = db.Column(db.Integer, primary_key=True)
11	    username = db.Column(db.String(50), unique=True, nullable=False)
12	    email = db.Column(db.String(100), unique=True, nullable=False)
13	    password_hash = db.Column(db.String(255), nullable=False)
14	    role = db.Column(db.String(20), default='user', nullable=False)  # 'user' or 'admin'
15	    created_at = db.Column(db.DateTime, default=datetime.utcnow)
16	    is_active = db.Column(db.Boolean, default=True)
17	    
18	    # Relationships
19	    subscriptions = db.relationship('Subscription', backref='user', lazy=True, cascade='all, delete-orphan')
20	    sightings = db.relationship('PokemonSighting', backref='reporter', lazy=True, cascade='all, delete-orphan')
21	    chat_messages = db.relationship('ChatMessage', backref='user', lazy=True, cascade='all, delete-orphan')
22	
23	    def __repr__(self):
24	        return f'<User {self.username}>'
25	
26	    def set_password(self, password):
27	        """Hash and set the user's password"""
28	        self.password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
29	
30	    def check_password(self, password):
31	        """Verify the user's password"""
32	        return bcrypt.checkpw(password.encode('utf-8'), self.password_hash.encode('utf-8'))
33	
34	    def to_dict(self):
35	        return {
36	            'id': self.id,
37	            'username': self.username,
38	            'email': self.email,
39	            'role': self.role,
40	            'created_at': self.created_at.isoformat() if self.created_at else None,
41	            'is_active': self.is_active
42	        }
43	
44	class Subscription(db.Model):
45	    __tablename__ = 'subscriptions'
46	    
47	    id = db.Column(db.Integer, primary_key=True)
48	    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
49	    plan_name = db.Column(db.String(50), default='Monthly Access')
50	    status = db.Column(db.String(20), default='active')  # 'active', 'inactive', 'pending'
51	    start_date = db.Column(db.Date, default=datetime.utcnow)
52	    end_date = db.Column(db.Date, nullable=True)
53	    stripe_customer_id = db.Column(db.String(255), nullable=True)
54	    
55	    def __repr__(self):
56	        return f'<Subscription {self.id} - User {self.user_id}>'
57	    
58	    def to_dict(self):
59	        return {
60	            'id': self.id,
61	            'user_id': self.user_id,
62	            'plan_name': self.plan_name,
63	            'status': self.status,
64	            'start_date': self.start_date.isoformat() if self.start_date else None,
65	            'end_date': self.end_date.isoformat() if self.end_date else None
66	        }
67	
68	class PokemonSighting(db.Model):
69	    __tablename__ = 'pokemon_sightings'
70	    
71	    id = db.Column(db.Integer, primary_key=True)
72	    reporter_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
73	    pokemon_name = db.Column(db.String(50), nullable=False)
74	    pokemon_type = db.Column(db.String(50), nullable=True)  # e.g., 'Water', 'Fire'
75	    latitude = db.Column(db.Float, nullable=False)
76	    longitude = db.Column(db.Float, nullable=False)
77	    time_reported = db.Column(db.DateTime, default=datetime.utcnow)
78	    time_found = db.Column(db.DateTime, nullable=True)
79	    is_verified = db.Column(db.Boolean, default=False)
80	    is_active = db.Column(db.Boolean, default=True)
81	    
82	    def __repr__(self):
83	        return f'<PokemonSighting {self.pokemon_name} at ({self.latitude}, {self.longitude})>'
84	    
85	    def to_dict(self):
86	        return {
87	            'id': self.id,
88	            'reporter_id': self.reporter_id,
89	            'reporter_username': self.reporter.username if self.reporter else None,
90	            'pokemon_name': self.pokemon_name,
91	            'pokemon_type': self.pokemon_type,
92	            'latitude': self.latitude,
93	            'longitude': self.longitude,
94	            'time_reported': self.time_reported.isoformat() if self.time_reported else None,
95	            'time_found': self.time_found.isoformat() if self.time_found else None,
96	            'is_verified': self.is_verified,
97	            'is_active': self.is_active
98	        }
99	
100	class ChatMessage(db.Model):
101	    __tablename__ = 'chat_messages'
102	    
103	    id = db.Column(db.Integer, primary_key=True)
104	    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
105	    message_text = db.Column(db.Text, nullable=False)
106	    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
107	    is_moderated = db.Column(db.Boolean, default=False)
108	    is_announcement = db.Column(db.Boolean, default=False)
109	    
110	    def __repr__(self):
111	        return f'<ChatMessage {self.id} by User {self.user_id}>'
112	    
113	    def to_dict(self):
114	        return {
115	            'id': self.id,
116	            'user_id': self.user_id,
117	            'username': self.user.username if self.user else None,
118	            'message_text': self.message_text,
119	            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
120	            'is_moderated': self.is_moderated,
121	            'is_announcement': self.is_announcement
122	        }
123	
124	