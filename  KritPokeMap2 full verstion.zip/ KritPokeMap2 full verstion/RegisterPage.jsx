Text file: RegisterPage.jsx
Latest content with line numbers:
1	import { useState } from 'react';
2	import { Link, useNavigate } from 'react-router-dom';
3	import { Button } from '@/components/ui/button';
4	import { Input } from '@/components/ui/input';
5	import { Label } from '@/components/ui/label';
6	import { MapPin, AlertCircle, CheckCircle } from 'lucide-react';
7	import { authAPI } from '@/lib/api';
8	
9	export default function RegisterPage({ onLogin }) {
10	  const navigate = useNavigate();
11	  const [formData, setFormData] = useState({
12	    username: '',
13	    email: '',
14	    password: '',
15	    confirmPassword: '',
16	  });
17	  const [error, setError] = useState('');
18	  const [loading, setLoading] = useState(false);
19	
20	  const handleChange = (e) => {
21	    setFormData({
22	      ...formData,
23	      [e.target.name]: e.target.value,
24	    });
25	    setError('');
26	  };
27	
28	  const handleSubmit = async (e) => {
29	    e.preventDefault();
30	    setError('');
31	
32	    // Validate passwords match
33	    if (formData.password !== formData.confirmPassword) {
34	      setError('Passwords do not match');
35	      return;
36	    }
37	
38	    // Validate password length
39	    if (formData.password.length < 6) {
40	      setError('Password must be at least 6 characters long');
41	      return;
42	    }
43	
44	    setLoading(true);
45	
46	    try {
47	      const response = await authAPI.register({
48	        username: formData.username,
49	        email: formData.email,
50	        password: formData.password,
51	      });
52	      
53	      const { user, token } = response.data;
54	      
55	      onLogin(user, token);
56	      navigate('/map');
57	    } catch (err) {
58	      setError(err.response?.data?.error || 'Registration failed. Please try again.');
59	    } finally {
60	      setLoading(false);
61	    }
62	  };
63	
64	  return (
65	    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-white to-gray-100 px-4 py-8">
66	      <div className="w-full max-w-md">
67	        {/* Logo */}
68	        <div className="text-center mb-8">
69	          <Link to="/" className="inline-flex items-center gap-2">
70	            <div className="w-12 h-12 rounded-full flex items-center justify-center" 
71	                 style={{ backgroundColor: 'var(--pokemon-yellow)' }}>
72	              <MapPin className="w-7 h-7" style={{ color: 'var(--pokemon-black)' }} />
73	            </div>
74	            <h1 className="text-3xl font-bold" style={{ color: 'var(--pokemon-black)' }}>
75	              KritPokeMap
76	            </h1>
77	          </Link>
78	        </div>
79	
80	        {/* Register Form */}
81	        <div className="bg-white rounded-lg shadow-xl p-8">
82	          <h2 className="text-2xl font-bold mb-2 text-center">Create Your Account</h2>
83	          <p className="text-center text-gray-600 mb-6">
84	            Start your 7-day free trial
85	          </p>
86	
87	          {error && (
88	            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-md flex items-center gap-2 text-red-700">
89	              <AlertCircle className="w-5 h-5" />
90	              <span>{error}</span>
91	            </div>
92	          )}
93	
94	          <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-md flex items-center gap-2 text-green-700">
95	            <CheckCircle className="w-5 h-5" />
96	            <span>7-day free trial included!</span>
97	          </div>
98	
99	          <form onSubmit={handleSubmit} className="space-y-4">
100	            <div>
101	              <Label htmlFor="username">Username</Label>
102	              <Input
103	                id="username"
104	                name="username"
105	                type="text"
106	                value={formData.username}
107	                onChange={handleChange}
108	                required
109	                placeholder="Choose a username"
110	              />
111	            </div>
112	
113	            <div>
114	              <Label htmlFor="email">Email</Label>
115	              <Input
116	                id="email"
117	                name="email"
118	                type="email"
119	                value={formData.email}
120	                onChange={handleChange}
121	                required
122	                placeholder="your@email.com"
123	              />
124	            </div>
125	
126	            <div>
127	              <Label htmlFor="password">Password</Label>
128	              <Input
129	                id="password"
130	                name="password"
131	                type="password"
132	                value={formData.password}
133	                onChange={handleChange}
134	                required
135	                placeholder="At least 6 characters"
136	              />
137	            </div>
138	
139	            <div>
140	              <Label htmlFor="confirmPassword">Confirm Password</Label>
141	              <Input
142	                id="confirmPassword"
143	                name="confirmPassword"
144	                type="password"
145	                value={formData.confirmPassword}
146	                onChange={handleChange}
147	                required
148	                placeholder="Re-enter your password"
149	              />
150	            </div>
151	
152	            <Button 
153	              type="submit" 
154	              className="w-full" 
155	              disabled={loading}
156	              style={{ 
157	                backgroundColor: 'var(--pokemon-yellow)', 
158	                color: 'var(--pokemon-black)' 
159	              }}
160	            >
161	              {loading ? 'Creating Account...' : 'Start Free Trial'}
162	            </Button>
163	          </form>
164	
165	          <div className="mt-6 text-center">
166	            <p className="text-gray-600">
167	              Already have an account?{' '}
168	              <Link to="/login" className="font-semibold" style={{ color: 'var(--pokemon-blue)' }}>
169	                Login here
170	              </Link>
171	            </p>
172	          </div>
173	        </div>
174	
175	        <div className="mt-6 text-center">
176	          <Link to="/" className="text-gray-600 hover:underline">
177	            ← Back to Home
178	          </Link>
179	        </div>
180	      </div>
181	    </div>
182	  );
183	}
184	
185	