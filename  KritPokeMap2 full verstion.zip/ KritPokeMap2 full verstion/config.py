import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.getenv('SECRET_KEY', 'kritpokemap-secret-key-2025')
    
    # For development, we'll use SQLite
    # For production, use PostgreSQL with PostGIS
    USE_POSTGRES = os.getenv('USE_POSTGRES', 'False').lower() == 'true'
    
    if USE_POSTGRES:
        SQLALCHEMY_DATABASE_URI = os.getenv(
            'DATABASE_URL',
            'postgresql://postgres:postgres@localhost:5432/kritpokemap'
        )
    else:
        # SQLite for development
        SQLALCHEMY_DATABASE_URI = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'database', 'app.db')}"
    
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # JWT Configuration
    JWT_SECRET_KEY = 'a_very_secret_key_for_kritpokemap_v1'
    JWT_ALGORITHM = 'HS256'
    JWT_EXPIRATION_HOURS = 24

