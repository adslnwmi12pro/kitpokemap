Text file: LoginPage.jsx
Latest content with line numbers:
1	import { useState } from 'react';
2	import { Link, useNavigate } from 'react-router-dom';
3	import { Button } from '@/components/ui/button';
4	import { Input } from '@/components/ui/input';
5	import { Label } from '@/components/ui/label';
6	import { MapPin, AlertCircle } from 'lucide-react';
7	import { authAPI } from '@/lib/api';
8	
9	export default function LoginPage({ onLogin }) {
10	  const navigate = useNavigate();
11	  const [formData, setFormData] = useState({
12	    username: '',
13	    password: '',
14	  });
15	  const [error, setError] = useState('');
16	  const [loading, setLoading] = useState(false);
17	
18	  const handleChange = (e) => {
19	    setFormData({
20	      ...formData,
21	      [e.target.name]: e.target.value,
22	    });
23	    setError('');
24	  };
25	
26	  const handleSubmit = async (e) => {
27	    e.preventDefault();
28	    setError('');
29	    setLoading(true);
30	
31	    try {
32	      const response = await authAPI.login(formData);
33	      const { user, token } = response.data;
34	      
35	      onLogin(user, token);
36	      navigate('/map');
37	    } catch (err) {
38	      setError(err.response?.data?.error || 'Login failed. Please try again.');
39	    } finally {
40	      setLoading(false);
41	    }
42	  };
43	
44	  return (
45	    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-white to-gray-100 px-4">
46	      <div className="w-full max-w-md">
47	        {/* Logo */}
48	        <div className="text-center mb-8">
49	          <Link to="/" className="inline-flex items-center gap-2">
50	            <div className="w-12 h-12 rounded-full flex items-center justify-center" 
51	                 style={{ backgroundColor: 'var(--pokemon-yellow)' }}>
52	              <MapPin className="w-7 h-7" style={{ color: 'var(--pokemon-black)' }} />
53	            </div>
54	            <h1 className="text-3xl font-bold" style={{ color: 'var(--pokemon-black)' }}>
55	              KritPokeMap
56	            </h1>
57	          </Link>
58	        </div>
59	
60	        {/* Login Form */}
61	        <div className="bg-white rounded-lg shadow-xl p-8">
62	          <h2 className="text-2xl font-bold mb-6 text-center">Login to Your Account</h2>
63	
64	          {error && (
65	            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-md flex items-center gap-2 text-red-700">
66	              <AlertCircle className="w-5 h-5" />
67	              <span>{error}</span>
68	            </div>
69	          )}
70	
71	          <form onSubmit={handleSubmit} className="space-y-4">
72	            <div>
73	              <Label htmlFor="username">Username</Label>
74	              <Input
75	                id="username"
76	                name="username"
77	                type="text"
78	                value={formData.username}
79	                onChange={handleChange}
80	                required
81	                placeholder="Enter your username"
82	              />
83	            </div>
84	
85	            <div>
86	              <Label htmlFor="password">Password</Label>
87	              <Input
88	                id="password"
89	                name="password"
90	                type="password"
91	                value={formData.password}
92	                onChange={handleChange}
93	                required
94	                placeholder="Enter your password"
95	              />
96	            </div>
97	
98	            <Button 
99	              type="submit" 
100	              className="w-full" 
101	              disabled={loading}
102	              style={{ 
103	                backgroundColor: 'var(--pokemon-yellow)', 
104	                color: 'var(--pokemon-black)' 
105	              }}
106	            >
107	              {loading ? 'Logging in...' : 'Login'}
108	            </Button>
109	          </form>
110	
111	          <div className="mt-6 text-center">
112	            <p className="text-gray-600">
113	              Don't have an account?{' '}
114	              <Link to="/register" className="font-semibold" style={{ color: 'var(--pokemon-blue)' }}>
115	                Register here
116	              </Link>
117	            </p>
118	          </div>
119	        </div>
120	
121	        <div className="mt-6 text-center">
122	          <Link to="/" className="text-gray-600 hover:underline">
123	            ← Back to Home
124	          </Link>
125	        </div>
126	      </div>
127	    </div>
128	  );
129	}
130	
131	