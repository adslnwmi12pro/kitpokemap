# KritPokeMap - คู่มือการ Deploy (Deployment Guide)

เอกสารนี้อธิบายขั้นตอนการ Deploy เว็บแอปพลิเคชัน **KritPokeMap** ไปยัง Production environment

---

## 📋 สารบัญ (Table of Contents)

1. [ข้อกำหนดเบื้องต้น](#ข้อกำหนดเบื้องต้น-prerequisites)
2. [การ Deploy Backend](#การ-deploy-backend)
3. [การ Deploy Frontend](#การ-deploy-frontend)
4. [การตั้งค่าฐานข้อมูล](#การตั้งค่าฐานข้อมูล)
5. [การตั้งค่า Environment Variables](#การตั้งค่า-environment-variables)
6. [การตั้งค่า Domain และ SSL](#การตั้งค่า-domain-และ-ssl)
7. [Monitoring และ Maintenance](#monitoring-และ-maintenance)

---

## 🔧 ข้อกำหนดเบื้องต้น (Prerequisites)

### **Server Requirements:**
- **OS:** Ubuntu 22.04 LTS หรือใหม่กว่า
- **RAM:** อย่างน้อย 2GB (แนะนำ 4GB+)
- **Storage:** อย่างน้อย 20GB
- **CPU:** อย่างน้อย 2 cores

### **Software Requirements:**
- Python 3.11+
- Node.js 22+
- PostgreSQL 14+ พร้อม PostGIS extension
- Nginx (สำหรับ Reverse Proxy)
- Supervisor หรือ systemd (สำหรับ Process Management)
- Certbot (สำหรับ SSL Certificate)

---

## 🚀 การ Deploy Backend

### **Option 1: Deploy ด้วย Gunicorn + Nginx**

#### **1.1 ติดตั้ง Gunicorn**

```bash
cd /home/ubuntu/kritpokemap_backend
source venv/bin/activate
pip install gunicorn
```

#### **1.2 สร้างไฟล์ wsgi.py**

```python
# /home/ubuntu/kritpokemap_backend/wsgi.py
from src.main import app

if __name__ == "__main__":
    app.run()
```

#### **1.3 ทดสอบรัน Gunicorn**

```bash
gunicorn --bind 0.0.0.0:8080 --workers 4 wsgi:app
```

#### **1.4 สร้าง Systemd Service**

```bash
sudo nano /etc/systemd/system/kritpokemap.service
```

เพิ่มเนื้อหา:

```ini
[Unit]
Description=KritPokeMap Flask Application
After=network.target

[Service]
User=ubuntu
Group=www-data
WorkingDirectory=/home/ubuntu/kritpokemap_backend
Environment="PATH=/home/ubuntu/kritpokemap_backend/venv/bin"
Environment="DATABASE_URL=postgresql://username:password@localhost:5432/kritpokemap"
Environment="JWT_SECRET_KEY=your-production-secret-key"
ExecStart=/home/ubuntu/kritpokemap_backend/venv/bin/gunicorn --bind 0.0.0.0:8080 --workers 4 wsgi:app
Restart=always

[Install]
WantedBy=multi-user.target
```

#### **1.5 เปิดใช้งาน Service**

```bash
sudo systemctl daemon-reload
sudo systemctl start kritpokemap
sudo systemctl enable kritpokemap
sudo systemctl status kritpokemap
```

---

### **Option 2: Deploy ด้วย Docker**

#### **2.1 สร้าง Dockerfile**

```dockerfile
# /home/ubuntu/kritpokemap_backend/Dockerfile
FROM python:3.11-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    postgresql-client \
    libpq-dev \
    && rm -rf /var/lib/apt/lists/*

# Copy requirements
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application
COPY . .

# Expose port
EXPOSE 8080

# Run application
CMD ["gunicorn", "--bind", "0.0.0.0:8080", "--workers", "4", "wsgi:app"]
```

#### **2.2 สร้าง docker-compose.yml**

```yaml
version: '3.8'

services:
  backend:
    build: ./kritpokemap_backend
    ports:
      - "8080:8080"
    environment:
      - DATABASE_URL=postgresql://postgres:password@db:5432/kritpokemap
      - JWT_SECRET_KEY=your-production-secret-key
    depends_on:
      - db
    restart: always

  db:
    image: postgis/postgis:14-3.3
    environment:
      - POSTGRES_DB=kritpokemap
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=password
    volumes:
      - postgres_data:/var/lib/postgresql/data
    restart: always

volumes:
  postgres_data:
```

#### **2.3 รัน Docker Compose**

```bash
docker-compose up -d
```

---

## 🌐 การ Deploy Frontend

### **Option 1: Deploy ด้วย Nginx (Static Files)**

#### **1.1 Build Frontend**

```bash
cd /home/ubuntu/kritpokemap_frontend
pnpm install
pnpm build
```

#### **1.2 คัดลอกไฟล์ไปยัง Nginx Directory**

```bash
sudo mkdir -p /var/www/kritpokemap
sudo cp -r dist/* /var/www/kritpokemap/
sudo chown -R www-data:www-data /var/www/kritpokemap
```

#### **1.3 ตั้งค่า Nginx**

```bash
sudo nano /etc/nginx/sites-available/kritpokemap
```

เพิ่มเนื้อหา:

```nginx
server {
    listen 80;
    server_name kritpokemap.com www.kritpokemap.com;

    root /var/www/kritpokemap;
    index index.html;

    # Frontend
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Backend API Proxy
    location /api/ {
        proxy_pass http://localhost:8080/api/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Gzip compression
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
}
```

#### **1.4 เปิดใช้งาน Site**

```bash
sudo ln -s /etc/nginx/sites-available/kritpokemap /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

---

### **Option 2: Deploy ด้วย Vercel/Netlify**

#### **2.1 Vercel**

```bash
cd /home/ubuntu/kritpokemap_frontend
npm install -g vercel
vercel login
vercel --prod
```

#### **2.2 Netlify**

```bash
cd /home/ubuntu/kritpokemap_frontend
npm install -g netlify-cli
netlify login
netlify deploy --prod --dir=dist
```

**หมายเหตุ:** ต้องตั้งค่า Environment Variable `VITE_API_URL` ให้ชี้ไปยัง Backend URL

---

## 🗄️ การตั้งค่าฐานข้อมูล

### **1. ติดตั้ง PostgreSQL และ PostGIS**

```bash
sudo apt update
sudo apt install postgresql postgresql-contrib postgis -y
```

### **2. สร้างฐานข้อมูล**

```bash
sudo -u postgres psql
```

```sql
CREATE DATABASE kritpokemap;
CREATE USER kritpoke_user WITH PASSWORD 'your-secure-password';
GRANT ALL PRIVILEGES ON DATABASE kritpokemap TO kritpoke_user;

\c kritpokemap
CREATE EXTENSION postgis;
\q
```

### **3. สร้างตาราง (Schema)**

```bash
cd /home/ubuntu/kritpokemap_backend
source venv/bin/activate
python -c "from src.main import db; db.create_all()"
```

หรือรัน SQL script:

```sql
-- Users Table
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(80) UNIQUE NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'user',
    is_active BOOLEAN DEFAULT TRUE,
    subscription_expires_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Pokemon Sightings Table
CREATE TABLE pokemon_sightings (
    id SERIAL PRIMARY KEY,
    pokemon_name VARCHAR(100) NOT NULL,
    pokemon_type VARCHAR(50),
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    location GEOGRAPHY(POINT, 4326),
    time_reported TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    reported_by INTEGER REFERENCES users(id),
    is_verified BOOLEAN DEFAULT FALSE
);

-- Chat Messages Table
CREATE TABLE chat_messages (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    message_text TEXT NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes
CREATE INDEX idx_sightings_location ON pokemon_sightings USING GIST(location);
CREATE INDEX idx_sightings_time ON pokemon_sightings(time_reported DESC);
CREATE INDEX idx_chat_timestamp ON chat_messages(timestamp DESC);
```

### **4. Backup และ Restore**

**Backup:**
```bash
pg_dump -U kritpoke_user -h localhost kritpokemap > backup_$(date +%Y%m%d).sql
```

**Restore:**
```bash
psql -U kritpoke_user -h localhost kritpokemap < backup_20251016.sql
```

---

## 🔐 การตั้งค่า Environment Variables

### **Backend (.env file)**

```bash
# /home/ubuntu/kritpokemap_backend/.env
DATABASE_URL=postgresql://kritpoke_user:your-secure-password@localhost:5432/kritpokemap
JWT_SECRET_KEY=your-very-secure-random-secret-key-here
FLASK_ENV=production
FLASK_DEBUG=0
```

### **Frontend (.env.production)**

```bash
# /home/ubuntu/kritpokemap_frontend/.env.production
VITE_API_URL=https://api.kritpokemap.com
```

**สร้าง Secret Key:**
```python
import secrets
print(secrets.token_urlsafe(32))
```

---

## 🌍 การตั้งค่า Domain และ SSL

### **1. ตั้งค่า DNS Records**

ไปที่ DNS Provider (Cloudflare, Namecheap, ฯลฯ) และเพิ่ม:

```
A Record:
kritpokemap.com → YOUR_SERVER_IP
www.kritpokemap.com → YOUR_SERVER_IP
api.kritpokemap.com → YOUR_SERVER_IP
```

### **2. ติดตั้ง SSL Certificate ด้วย Certbot**

```bash
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d kritpokemap.com -d www.kritpokemap.com
```

Certbot จะอัปเดต Nginx config อัตโนมัติ

### **3. ตั้งค่า Auto-renewal**

```bash
sudo certbot renew --dry-run
```

Certbot จะ renew certificate อัตโนมัติทุก 60 วัน

---

## 📊 Monitoring และ Maintenance

### **1. ตรวจสอบ Logs**

**Backend Logs:**
```bash
sudo journalctl -u kritpokemap -f
```

**Nginx Logs:**
```bash
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log
```

**PostgreSQL Logs:**
```bash
sudo tail -f /var/log/postgresql/postgresql-14-main.log
```

### **2. ติดตั้ง Monitoring Tools**

**Option 1: PM2 (สำหรับ Node.js/Python)**
```bash
npm install -g pm2
pm2 start "gunicorn --bind 0.0.0.0:8080 --workers 4 wsgi:app" --name kritpokemap
pm2 startup
pm2 save
```

**Option 2: Uptime Monitoring**
- [UptimeRobot](https://uptimerobot.com/)
- [Pingdom](https://www.pingdom.com/)

### **3. Database Maintenance**

**ทำความสะอาดข้อมูลเก่า (Sightings > 7 วัน):**
```sql
DELETE FROM pokemon_sightings 
WHERE time_reported < NOW() - INTERVAL '7 days';
```

**ทำความสะอาดข้อความแชทเก่า (> 30 วัน):**
```sql
DELETE FROM chat_messages 
WHERE timestamp < NOW() - INTERVAL '30 days';
```

**Vacuum Database:**
```bash
sudo -u postgres psql kritpokemap -c "VACUUM ANALYZE;"
```

### **4. Security Updates**

```bash
sudo apt update
sudo apt upgrade -y
sudo systemctl restart kritpokemap
sudo systemctl reload nginx
```

---

## 🔄 CI/CD Pipeline (Optional)

### **GitHub Actions Example**

```yaml
# .github/workflows/deploy.yml
name: Deploy KritPokeMap

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Deploy to Server
      uses: appleboy/ssh-action@master
      with:
        host: ${{ secrets.SERVER_HOST }}
        username: ubuntu
        key: ${{ secrets.SSH_PRIVATE_KEY }}
        script: |
          cd /home/ubuntu/kritpokemap_backend
          git pull origin main
          source venv/bin/activate
          pip install -r requirements.txt
          sudo systemctl restart kritpokemap
          
          cd /home/ubuntu/kritpokemap_frontend
          git pull origin main
          pnpm install
          pnpm build
          sudo cp -r dist/* /var/www/kritpokemap/
          sudo systemctl reload nginx
```

---

## 📝 Checklist สำหรับ Production

- [ ] ตั้งค่า `FLASK_ENV=production`
- [ ] ปิด `FLASK_DEBUG`
- [ ] เปลี่ยน `JWT_SECRET_KEY` เป็นค่าที่ปลอดภัย
- [ ] ตั้งค่า Database password ที่แข็งแรง
- [ ] เปิดใช้งาน SSL Certificate
- [ ] ตั้งค่า Firewall (UFW)
  ```bash
  sudo ufw allow 80/tcp
  sudo ufw allow 443/tcp
  sudo ufw allow 22/tcp
  sudo ufw enable
  ```
- [ ] ตั้งค่า CORS ให้ถูกต้อง
- [ ] เปิดใช้งาน Gzip compression
- [ ] ตั้งค่า Rate Limiting
- [ ] สร้าง Backup Schedule
- [ ] ตั้งค่า Monitoring และ Alerting
- [ ] ทดสอบ Load Testing

---

## 🆘 Troubleshooting

### **ปัญหา: Backend ไม่สามารถเชื่อมต่อฐานข้อมูล**
```bash
# ตรวจสอบ PostgreSQL service
sudo systemctl status postgresql

# ตรวจสอบ connection string
echo $DATABASE_URL
```

### **ปัญหา: Frontend ไม่สามารถเรียก API**
- ตรวจสอบ CORS configuration ใน Backend
- ตรวจสอบ `VITE_API_URL` ใน Frontend
- ตรวจสอบ Nginx proxy configuration

### **ปัญหา: SSL Certificate Error**
```bash
sudo certbot renew --force-renewal
sudo systemctl reload nginx
```

---

## 📞 Support

หากพบปัญหาในการ Deploy สามารถตรวจสอบ:
- Backend logs: `sudo journalctl -u kritpokemap -f`
- Nginx logs: `sudo tail -f /var/log/nginx/error.log`
- Database logs: `sudo tail -f /var/log/postgresql/postgresql-14-main.log`

---

**สรุป:** เอกสารนี้ครอบคลุมขั้นตอนการ Deploy KritPokeMap ไปยัง Production environment อย่างสมบูรณ์ รวมถึงการตั้งค่า Security, Monitoring และ Maintenance ครับ! 🚀

