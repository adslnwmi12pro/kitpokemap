# KritPokeMap System Architecture Design

## 1. Goal
To develop a full-stack web application, "KritPokeMap," that provides a real-time map-based service for tracking Pokémon locations, initially focused on Kanchanaburi province, Thailand. The application must include a subscription-based membership system, user authentication, an admin dashboard, and real-time communication features.

## 2. Technology Stack

| Component | Technology | Rationale |
| :--- | :--- | :--- |
| **Frontend** | **React** (with Vite/Next.js for setup) | Modern, component-based UI for complex interactions (map, real-time chat). |
| **Styling/UI** | **Tailwind CSS** / **Styled Components** | Rapid, utility-first styling to implement the specific Pokémon theme colors (Yellow, Black, Gray, Blue) and responsive design. |
| **Thai Font** | **Sukhumvit** | To meet the user's specific requirement for a modern Thai font. |
| **Backend (API)** | **Node.js** with **Express** or **Python** with **FastAPI** | High performance, scalable for real-time data handling (FastAPI is chosen for its speed and modern Python features). |
| **Database** | **PostgreSQL** (with PostGIS extension) | Robust, supports complex queries, and essential for geospatial data storage (PostGIS) required for the map features. |
| **Real-time Communication** | **WebSockets** (via **Socket.IO** or similar library) | Necessary for real-time chat/comments and instant map updates (crowdsourcing data). |
| **Mapping** | **Leaflet.js** or **Mapbox GL JS** (with OpenStreetMap data) | Open-source and customizable map library suitable for displaying custom markers and overlays. |
| **Authentication** | **JWT (JSON Web Tokens)** | Standard, secure method for handling user sessions and protecting API routes. |
| **Payment/Subscription** | **Stripe** (Placeholder for a real-world implementation) | Industry-standard for handling recurring monthly subscriptions. |

## 3. System Architecture (High-Level)

The system will follow a **Microservices/Monolithic Hybrid** approach, primarily a Monolithic structure for simplicity but with clear separation of concerns.

1.  **Client (Frontend):** React application responsible for rendering the UI, map, and handling user interactions. Communicates with the API and WebSocket server.
2.  **API Server (Backend):** FastAPI application handling business logic, user authentication, subscription management, and serving data from the database.
3.  **Database:** PostgreSQL/PostGIS storing user data, subscription status, admin logs, and **geospatial Pokémon location data**.
4.  **WebSocket Server:** Dedicated server (or integrated into the API server) for real-time data exchange (chat messages, new crowdsourced Pokémon sightings).

## 4. Key Modules and Features

| Module | Features |
| :--- | :--- |
| **Map Module** | Display Kanchanaburi map, search/filter Pokémon by type/location, display real-time Pokémon markers (from API/Crowdsourcing). |
| **Authentication/Membership** | User registration, Login/Logout, JWT-based session management, Monthly subscription payment gateway integration, Subscription status check (access control). |
| **Crowdsourcing Module (Fallback)** | User interface to report a Pokémon sighting (location, type, time), API endpoint to validate and store the report. |
| **Real-time Chat/Comments** | Live comment feed on the map or a dedicated sidebar, real-time news/announcements from admins. |
| **Admin Dashboard** | User management (view/suspend/delete), Subscription monitoring, Content moderation (chat/crowdsourced data), Usage logging. |
| **Internationalization (i18n)** | Support for English and Thai languages. |
| **Social Integration** | Buttons/links for sharing the web app on all major social media platforms. |

## 5. Phase 1 Conclusion

The architecture is designed to be robust, scalable, and capable of handling real-time data, which is crucial for a map-based application. The next step is to research the feasibility of the primary data source (Approach B).
