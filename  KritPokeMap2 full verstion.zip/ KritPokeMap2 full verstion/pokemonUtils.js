// Pokemon utilities for KritPokeMap

// Pokemon data with IDs from PokeAPI
export const pokemonData = {
  'Pikachu': { id: 25, type: 'Electric' },
  'Charizard': { id: 6, type: 'Fire' },
  'Blastoise': { id: 9, type: 'Water' },
  'Venusaur': { id: 3, type: 'Grass' },
  'Mewtwo': { id: 150, type: 'Psychic' },
  'Dragonite': { id: 149, type: 'Dragon' },
  'Gyarados': { id: 130, type: 'Water' },
  'Snorlax': { id: 143, type: 'Normal' },
  'Lapras': { id: 131, type: 'Water' },
  'Gengar': { id: 94, type: 'Ghost' },
  'Alakazam': { id: 65, type: 'Psychic' },
  'Machamp': { id: 68, type: 'Fighting' },
  'Golem': { id: 76, type: 'Rock' },
  'Arcanine': { id: 59, type: 'Fire' },
  'Jolteon': { id: 135, type: 'Electric' },
  'Vaporeon': { id: 134, type: 'Water' },
  'Flareon': { id: 136, type: 'Fire' },
  'Eevee': { id: 133, type: 'Normal' },
  'Bulbasaur': { id: 1, type: 'Grass' },
  'Charmander': { id: 4, type: 'Fire' },
  'Squirtle': { id: 7, type: 'Water' },
  'Pidgeot': { id: 18, type: 'Flying' },
  'Raichu': { id: 26, type: 'Electric' },
  'Nidoking': { id: 34, type: 'Poison' },
  'Clefable': { id: 36, type: 'Fairy' },
  'Ninetales': { id: 38, type: 'Fire' },
  'Wigglytuff': { id: 40, type: 'Fairy' },
  'Vileplume': { id: 45, type: 'Grass' },
  'Parasect': { id: 47, type: 'Bug' },
  'Golduck': { id: 55, type: 'Water' },
  'Primeape': { id: 57, type: 'Fighting' },
  'Poliwrath': { id: 62, type: 'Water' },
  'Victreebel': { id: 71, type: 'Grass' },
  'Rapidash': { id: 78, type: 'Fire' },
  'Slowbro': { id: 80, type: 'Water' },
  'Magneton': { id: 82, type: 'Electric' },
  'Dodrio': { id: 85, type: 'Flying' },
  'Dewgong': { id: 87, type: 'Water' },
  'Muk': { id: 89, type: 'Poison' },
  'Cloyster': { id: 91, type: 'Water' },
  'Hypno': { id: 97, type: 'Psychic' },
  'Kingler': { id: 99, type: 'Water' },
  'Electrode': { id: 101, type: 'Electric' },
  'Exeggutor': { id: 103, type: 'Grass' },
  'Marowak': { id: 105, type: 'Ground' },
  'Hitmonlee': { id: 106, type: 'Fighting' },
  'Hitmonchan': { id: 107, type: 'Fighting' },
  'Weezing': { id: 110, type: 'Poison' },
  'Rhydon': { id: 112, type: 'Ground' },
  'Chansey': { id: 113, type: 'Normal' },
  'Tangela': { id: 114, type: 'Grass' },
  'Kangaskhan': { id: 115, type: 'Normal' },
  'Seadra': { id: 117, type: 'Water' },
  'Seaking': { id: 119, type: 'Water' },
  'Starmie': { id: 121, type: 'Water' },
  'Mr. Mime': { id: 122, type: 'Psychic' },
  'Scyther': { id: 123, type: 'Bug' },
  'Jynx': { id: 124, type: 'Ice' },
  'Electabuzz': { id: 125, type: 'Electric' },
  'Magmar': { id: 126, type: 'Fire' },
  'Pinsir': { id: 127, type: 'Bug' },
  'Tauros': { id: 128, type: 'Normal' },
  'Magikarp': { id: 129, type: 'Water' },
  'Ditto': { id: 132, type: 'Normal' },
  'Porygon': { id: 137, type: 'Normal' },
  'Omanyte': { id: 138, type: 'Rock' },
  'Omastar': { id: 139, type: 'Rock' },
  'Kabuto': { id: 140, type: 'Rock' },
  'Kabutops': { id: 141, type: 'Rock' },
  'Aerodactyl': { id: 142, type: 'Rock' },
  'Articuno': { id: 144, type: 'Ice' },
  'Zapdos': { id: 145, type: 'Electric' },
  'Moltres': { id: 146, type: 'Fire' },
  'Dratini': { id: 147, type: 'Dragon' },
  'Dragonair': { id: 148, type: 'Dragon' },
  'Mew': { id: 151, type: 'Psychic' },
};

// Get Pokemon sprite URL from PokeAPI
export function getPokemonSpriteUrl(pokemonName) {
  const pokemon = pokemonData[pokemonName];
  if (!pokemon) {
    // Default to Pikachu if Pokemon not found
    return 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/25.png';
  }
  return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${pokemon.id}.png`;
}

// Get Pokemon sprite URL by ID
export function getPokemonSpriteById(id) {
  return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${id}.png`;
}

// Get Pokemon type
export function getPokemonType(pokemonName) {
  const pokemon = pokemonData[pokemonName];
  return pokemon ? pokemon.type : 'Normal';
}

// Get Pokemon ID
export function getPokemonId(pokemonName) {
  const pokemon = pokemonData[pokemonName];
  return pokemon ? pokemon.id : 25; // Default to Pikachu
}

// Get all Pokemon names
export function getAllPokemonNames() {
  return Object.keys(pokemonData);
}

// Get Pokemon by type
export function getPokemonByType(type) {
  return Object.entries(pokemonData)
    .filter(([_, data]) => data.type === type)
    .map(([name, _]) => name);
}

// Get random Pokemon
export function getRandomPokemon() {
  const names = getAllPokemonNames();
  return names[Math.floor(Math.random() * names.length)];
}

// Get popular Pokemon for landing page decoration
export function getPopularPokemon() {
  return ['Pikachu', 'Charizard', 'Blastoise', 'Venusaur', 'Mewtwo', 'Dragonite', 'Eevee', 'Snorlax'];
}

export default {
  pokemonData,
  getPokemonSpriteUrl,
  getPokemonSpriteById,
  getPokemonType,
  getPokemonId,
  getAllPokemonNames,
  getPokemonByType,
  getRandomPokemon,
  getPopularPokemon,
};

