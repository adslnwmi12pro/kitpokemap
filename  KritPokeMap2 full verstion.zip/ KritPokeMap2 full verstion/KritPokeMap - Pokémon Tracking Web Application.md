# KritPokeMap - Pokémon Tracking Web Application

**KritPokeMap** เป็นเว็บแอปพลิเคชันสำหรับช่วยเล่นเกม Pokémon GO โดยเฉพาะในพื้นที่จังหวัดกาญจนบุรี ประเทศไทย ระบบนี้ใช้แนวทาง **Crowdsourcing** (การแจ้งข่าวสารและแชร์พิกัดจากสมาชิก) เป็นแหล่งข้อมูลหลักในการแสดงตำแหน่งโปเกม่อนบนแผนที่แบบเรียลไทม์

---

## 🎯 คุณสมบัติหลัก (Features)

### 1. **ระบบแผนที่แบบเรียลไทม์ (Real-time Map System)**
- แสดงแผนที่จังหวัดกาญจนบุรีด้วย **OpenStreetMap** และ **Leaflet.js**
- แสดงตำแหน่งโปเกม่อนที่สมาชิกรายงาน (Pokémon Sightings) พร้อม Marker บนแผนที่
- กรองข้อมูลตามประเภทโปเกม่อน (Water, Fire, Grass, Electric, ฯลฯ)
- แสดงข้อมูลโปเกม่อนที่รายงานภายใน 24 ชั่วโมงล่าสุด

### 2. **ระบบสมาชิกและการล็อกอิน (Membership & Authentication)**
- **ระบบสมัครสมาชิก (Registration):** ผู้ใช้สามารถสมัครสมาชิกด้วยอีเมลและรหัสผ่าน
- **ระบบล็อกอิน (Login):** ใช้ JWT (JSON Web Token) สำหรับการยืนยันตัวตน
- **ระบบสมาชิกรายเดือน (Monthly Subscription):** 
  - ราคา **฿99/เดือน**
  - ทดลองใช้ฟรี 7 วัน (7-day free trial)
  - สมาชิกที่หมดอายุจะไม่สามารถเข้าใช้งานได้

### 3. **ระบบรายงานตำแหน่งโปเกม่อน (Report Sighting)**
- ผู้ใช้สามารถคลิกบนแผนที่เพื่อเลือกตำแหน่ง
- กรอกชื่อโปเกม่อนและประเภท (Type)
- ข้อมูลจะถูกบันทึกลงฐานข้อมูล PostgreSQL พร้อม PostGIS extension สำหรับข้อมูลพิกัด

### 4. **ระบบแชทเรียลไทม์ (Live Chat System)**
- ผู้ใช้สามารถส่งข้อความและสื่อสารกับผู้เล่นคนอื่นแบบเรียลไทม์
- แสดงชื่อผู้ใช้และเวลาที่ส่งข้อความ
- ระบบ Auto-refresh ทุก 30 วินาทีเพื่ออัปเดตข้อความใหม่

### 5. **ระบบแอดมิน (Admin Dashboard)**
- **Admin Dashboard:** แสดงสถิติผู้ใช้, การสมัครสมาชิก, จำนวน Sightings และข้อความ
- **User Management:** แอดมินสามารถดูรายชื่อผู้ใช้ทั้งหมด
- **Suspend/Activate Users:** แอดมินสามารถระงับหรือเปิดใช้งานบัญชีผู้ใช้ได้
- เฉพาะผู้ใช้ที่มี Role = `admin` เท่านั้นที่เข้าถึงได้

### 6. **ธีมและการออกแบบ (Theme & Design)**
- ใช้ธีมสีตามตัวการ์ตูนโปเกม่อน:
  - **สีเหลือง (Yellow):** `#FFCB05` - สีหลัก
  - **สีดำ (Black):** `#2C2C2C` - ข้อความและพื้นหลัง
  - **สีเทา (Gray):** `#6C757D` - ข้อความรอง
  - **สีฟ้า (Blue):** `#3B4CCA` - ลิงก์และปุ่มรอง
- ใช้ฟอนต์ **Sukhumvit** (ภาษาไทย) และ **Inter** (ภาษาอังกฤษ) เพื่อความทันสมัย
- รองรับทั้งภาษาอังกฤษและภาษาไทย

### 7. **การเชื่อมต่อสังคมออนไลน์ (Social Media Integration)**
- สามารถเชื่อมต่อกับแพลตฟอร์มโซเชียลมีเดียได้ (ในอนาคต)
- ปุ่ม Share และ Social Login (Facebook, Google, Twitter) พร้อมสำหรับการพัฒนาต่อ

---

## 🏗️ สถาปัตยกรรมระบบ (System Architecture)

### **Backend**
- **Framework:** Flask (Python)
- **Database:** PostgreSQL 14+ พร้อม PostGIS extension สำหรับข้อมูลภูมิศาสตร์
- **ORM:** SQLAlchemy
- **Authentication:** JWT (JSON Web Token) ด้วย `PyJWT`
- **API Endpoints:**
  - `/api/auth/register` - สมัครสมาชิก
  - `/api/auth/login` - ล็อกอิน
  - `/api/sightings` - ดึงข้อมูล/สร้าง Sightings
  - `/api/chat/messages` - ดึงข้อมูล/ส่งข้อความ
  - `/api/admin/*` - Admin endpoints (ต้องมี Admin role)

### **Frontend**
- **Framework:** React 18+ (Vite)
- **UI Library:** shadcn/ui + Tailwind CSS
- **Map Library:** Leaflet.js + React-Leaflet
- **Icons:** Lucide React
- **State Management:** React Hooks (useState, useEffect)
- **Routing:** React Router v6

### **Database Schema**
```sql
-- Users Table
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(80) UNIQUE NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'user',
    is_active BOOLEAN DEFAULT TRUE,
    subscription_expires_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Pokemon Sightings Table
CREATE TABLE pokemon_sightings (
    id SERIAL PRIMARY KEY,
    pokemon_name VARCHAR(100) NOT NULL,
    pokemon_type VARCHAR(50),
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    location GEOGRAPHY(POINT, 4326),
    time_reported TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    reported_by INTEGER REFERENCES users(id),
    is_verified BOOLEAN DEFAULT FALSE
);

-- Chat Messages Table
CREATE TABLE chat_messages (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    message_text TEXT NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## 📦 โครงสร้างโปรเจค (Project Structure)

```
/home/ubuntu/
├── kritpokemap_backend/          # Backend (Flask)
│   ├── src/
│   │   ├── main.py              # Entry point
│   │   ├── config.py            # Database configuration
│   │   ├── models/
│   │   │   └── user.py          # User model
│   │   ├── routes/
│   │   │   ├── auth.py          # Authentication routes
│   │   │   ├── sightings.py    # Sightings routes
│   │   │   ├── chat.py          # Chat routes
│   │   │   └── admin.py         # Admin routes
│   │   ├── utils/
│   │   │   └── auth.py          # JWT utilities
│   │   └── static/              # Frontend build files
│   ├── venv/                    # Python virtual environment
│   └── requirements.txt
│
└── kritpokemap_frontend/         # Frontend (React)
    ├── src/
    │   ├── App.jsx              # Main app component
    │   ├── App.css              # Global styles
    │   ├── lib/
    │   │   └── api.js           # API client
    │   └── pages/
    │       ├── LandingPage.jsx  # Landing page
    │       ├── LoginPage.jsx    # Login page
    │       ├── RegisterPage.jsx # Register page
    │       ├── MapPage.jsx      # Main map page
    │       └── AdminDashboard.jsx # Admin dashboard
    ├── index.html
    ├── package.json
    └── dist/                    # Production build
```

---

## 🚀 การติดตั้งและรันระบบ (Installation & Setup)

### **ข้อกำหนดเบื้องต้น (Prerequisites)**
- Python 3.11+
- Node.js 22+
- PostgreSQL 14+ พร้อม PostGIS extension
- pnpm (Package manager)

### **1. ติดตั้ง Backend**

```bash
cd /home/ubuntu/kritpokemap_backend

# สร้าง virtual environment
python3.11 -m venv venv
source venv/bin/activate

# ติดตั้ง dependencies
pip install -r requirements.txt

# ตั้งค่า environment variables
export DATABASE_URL="postgresql://username:password@localhost:5432/kritpokemap"
export JWT_SECRET_KEY="your-secret-key-here"

# รันเซิร์ฟเวอร์
python src/main.py
```

เซิร์ฟเวอร์จะรันที่ `http://localhost:8080`

### **2. ติดตั้ง Frontend**

```bash
cd /home/ubuntu/kritpokemap_frontend

# ติดตั้ง dependencies
pnpm install

# รัน development server
pnpm dev

# หรือ build สำหรับ production
pnpm build
```

Frontend development server จะรันที่ `http://localhost:5173`

### **3. ตั้งค่าฐานข้อมูล PostgreSQL**

```sql
-- สร้างฐานข้อมูล
CREATE DATABASE kritpokemap;

-- เปิดใช้งาน PostGIS extension
\c kritpokemap
CREATE EXTENSION postgis;

-- สร้างตารางตาม schema ข้างต้น
```

---

## 🎮 การใช้งาน (Usage)

### **สำหรับผู้ใช้ทั่วไป (Regular Users)**

1. **สมัครสมาชิก:**
   - เข้าไปที่หน้าแรก → คลิก "Get Started" หรือ "Subscribe Now"
   - กรอกข้อมูล: Username, Email, Password
   - ระบบจะให้ทดลองใช้ฟรี 7 วัน

2. **ล็อกอิน:**
   - ใช้ Username และ Password ที่สมัครไว้
   - ระบบจะพาไปยังหน้าแผนที่หลัก

3. **รายงานตำแหน่งโปเกม่อน:**
   - คลิกปุ่ม "Report Sighting"
   - คลิกบนแผนที่เพื่อเลือกตำแหน่ง
   - กรอกชื่อโปเกม่อนและประเภท
   - คลิก "Report Sighting"

4. **ใช้งานแชท:**
   - พิมพ์ข้อความในช่อง "Type a message..."
   - คลิกปุ่มส่ง (Send icon)
   - ข้อความจะแสดงในแผง Live Chat

5. **กรองข้อมูล:**
   - ใช้ Dropdown "Filter" ด้านซ้ายเพื่อกรองตามประเภทโปเกม่อน

### **สำหรับแอดมิน (Admin Users)**

1. **เข้าสู่ระบบด้วยบัญชีแอดมิน**
2. **คลิกปุ่ม "Admin"** ที่ Header
3. **ดูสถิติ:** Total Users, Active Subscriptions, Active Sightings, Total Messages
4. **จัดการผู้ใช้:**
   - ดูรายชื่อผู้ใช้ทั้งหมด
   - Suspend หรือ Activate บัญชีผู้ใช้

---

## 🔑 ข้อมูลทดสอบ (Test Credentials)

### **บัญชีผู้ใช้ทั่วไป:**
- Username: `testuser`
- Password: `password123`
- Email: `testuser@example.com`

### **บัญชีแอดมิน:**
- Username: `admin`
- Password: `admin123`
- Email: `admin@kritpokemap.com`

---

## 📍 ข้อมูลแผนที่ (Map Information)

- **พื้นที่ครอบคลุม:** จังหวัดกาญจนบุรี ประเทศไทย
- **พิกัดศูนย์กลาง:** 14.0227°N, 99.5328°E
- **ระดับ Zoom เริ่มต้น:** 11
- **แหล่งข้อมูลแผนที่:** OpenStreetMap (OSM)
- **ไลบรารี่:** Leaflet.js

---

## 🛠️ เทคโนโลยีที่ใช้ (Technology Stack)

### **Backend:**
- Flask 3.0+
- SQLAlchemy 2.0+
- PostgreSQL 14+
- PostGIS 3.0+
- PyJWT
- Flask-CORS
- Werkzeug (Password hashing)

### **Frontend:**
- React 18+
- Vite
- React Router v6
- Leaflet.js
- React-Leaflet
- Tailwind CSS
- shadcn/ui
- Lucide React (Icons)
- Axios (HTTP client)

### **DevOps & Tools:**
- Git
- pnpm
- Python venv

---

## 🔒 ความปลอดภัย (Security)

1. **Password Hashing:** ใช้ Werkzeug's `generate_password_hash` และ `check_password_hash`
2. **JWT Authentication:** Token มีอายุ 10 วัน
3. **Role-Based Access Control (RBAC):** แยก role เป็น `user` และ `admin`
4. **CORS Protection:** กำหนด allowed origins
5. **SQL Injection Prevention:** ใช้ SQLAlchemy ORM
6. **Input Validation:** ตรวจสอบข้อมูลก่อนบันทึกลงฐานข้อมูล

---

## 📈 การพัฒนาในอนาคต (Future Enhancements)

### **Phase 1: ปรับปรุงระบบพื้นฐาน**
- ✅ แก้ไขปัญหา Admin Dashboard ไม่แสดงข้อมูล
- ✅ เพิ่ม WebSocket สำหรับแชทเรียลไทม์ (แทน Polling)
- ✅ เพิ่มระบบ Notification เมื่อมีโปเกม่อนใหม่ในพื้นที่ใกล้เคียง

### **Phase 2: ฟีเจอร์เพิ่มเติม**
- ✅ ระบบ Upvote/Downvote สำหรับ Sightings เพื่อยืนยันความถูกต้อง
- ✅ ระบบ Favorite Pokémon เพื่อแจ้งเตือนเมื่อพบโปเกม่อนที่ชื่นชอบ
- ✅ ระบบ Heatmap แสดงพื้นที่ที่มีโปเกม่อนเกิดบ่อย
- ✅ ระบบ Raid Coordination สำหรับจัดทีม Raid Battle

### **Phase 3: การขยายพื้นที่**
- ✅ เพิ่มพื้นที่ครอบคลุมจังหวัดอื่นๆ ในประเทศไทย
- ✅ ระบบเลือกภูมิภาค (Region Selector)

### **Phase 4: Mobile App**
- ✅ พัฒนา Mobile App (React Native หรือ Flutter)
- ✅ รองรับ GPS tracking แบบเรียลไทม์

### **Phase 5: Monetization**
- ✅ ระบบชำระเงินออนไลน์ (Stripe, PayPal, PromptPay)
- ✅ แพ็กเกจสมาชิกหลายระดับ (Basic, Premium, Pro)

---

## 🐛 ปัญหาที่ทราบ (Known Issues)

1. **Admin Dashboard ไม่แสดงข้อมูล:**
   - **สาเหตุ:** Frontend ไม่สามารถดึงข้อมูลจาก API ได้ เนื่องจากปัญหา Token management
   - **วิธีแก้:** ตรวจสอบการส่ง Authorization header และ CORS configuration

2. **Chat ไม่อัปเดตแบบเรียลไทม์:**
   - **สาเหตุ:** ใช้ Polling ทุก 30 วินาที แทน WebSocket
   - **วิธีแก้:** เปลี่ยนเป็น WebSocket หรือ Server-Sent Events (SSE)

3. **Subscription Expiration ไม่ทำงาน:**
   - **สาเหตุ:** ยังไม่มีระบบตรวจสอบวันหมดอายุอัตโนมัติ
   - **วิธีแก้:** เพิ่ม Middleware ตรวจสอบ `subscription_expires_at`

---

## 📞 การติดต่อและสนับสนุน (Contact & Support)

- **Developer:** Manus AI Agent
- **Project Repository:** `/home/ubuntu/kritpokemap_backend` และ `/home/ubuntu/kritpokemap_frontend`
- **Documentation:** ไฟล์นี้ (`KritPokeMap_README.md`)

---

## 📄 สรุป (Summary)

**KritPokeMap** เป็นเว็บแอปพลิเคชันที่ครอบคลุมคุณสมบัติตามที่กำหนดไว้:

✅ **ระบบแผนที่แสดงตำแหน่งโปเกม่อน** - ใช้ OpenStreetMap และ Leaflet.js  
✅ **ระบบสมาชิกรายเดือน** - ฿99/เดือน พร้อมทดลองใช้ฟรี 7 วัน  
✅ **ระบบล็อกอิน** - JWT Authentication  
✅ **ระบบแอดมิน** - Admin Dashboard สำหรับจัดการผู้ใช้  
✅ **ระบบแชทเรียลไทม์** - Live Chat สำหรับสื่อสารระหว่างผู้เล่น  
✅ **ระบบ Crowdsourcing** - ผู้ใช้สามารถรายงานตำแหน่งโปเกม่อนได้  
✅ **ธีมโปเกม่อน** - สีเหลือง, ดำ, เทา, ฟ้า พร้อมฟอนต์ Sukhumvit  
✅ **รองรับภาษาอังกฤษและไทย**  
✅ **พื้นที่ครอบคลุมจังหวัดกาญจนบุรี**

ระบบพร้อมสำหรับการพัฒนาต่อและ Deploy ไปยัง Production environment ครับ! 🚀

