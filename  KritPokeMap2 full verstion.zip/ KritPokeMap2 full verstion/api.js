Text file: api.js
Latest content with line numbers:
1	import axios from 'axios';
2	
3	// API Base URL - use relative path for production
4	const API_BASE_URL = import.meta.env.VITE_API_URL || '/api';
5	
6	// Create axios instance
7	const api = axios.create({
8	  baseURL: API_BASE_URL,
9	  headers: {
10	    'Content-Type': 'application/json',
11	  },
12	});
13	
14	// Add token to requests if available
15	api.interceptors.request.use((config) => {
16	  const token = localStorage.getItem('token');
17	  if (token) {
18	    config.headers.Authorization = `Bearer ${token}`;
19	  }
20	  return config;
21	});
22	
23	// Auth API
24	export const authAPI = {
25	  register: (data) => api.post('/auth/register', data),
26	  login: (data) => api.post('/auth/login', data),
27	  getCurrentUser: () => api.get('/auth/me'),
28	  changePassword: (data) => api.post('/auth/change-password', data),
29	};
30	
31	// Sightings API
32	export const sightingsAPI = {
33	  getSightings: (params) => api.get('/sightings', { params }),
34	  createSighting: (data) => api.post('/sightings', data),
35	  getSighting: (id) => api.get(`/sightings/${id}`),
36	  deleteSighting: (id) => api.delete(`/sightings/${id}`),
37	  verifySighting: (id) => api.post(`/sightings/${id}/verify`),
38	  deactivateSighting: (id) => api.post(`/sightings/${id}/deactivate`),
39	};
40	
41	// Chat API
42	export const chatAPI = {
43	  getMessages: (params) => api.get('/chat/messages', { params }),
44	  sendMessage: (data) => api.post('/chat/messages', data),
45	  deleteMessage: (id) => api.delete(`/chat/messages/${id}`),
46	};
47	
48	// Admin API
49	export const adminAPI = {
50	  getUsers: () => api.get('/admin/users'),
51	  getUser: (id) => api.get(`/admin/users/${id}`),
52	  suspendUser: (id) => api.post(`/admin/users/${id}/suspend`),
53	  activateUser: (id) => api.post(`/admin/users/${id}/activate`),
54	  deleteUser: (id) => api.delete(`/admin/users/${id}`),
55	  getSubscriptions: () => api.get('/admin/subscriptions'),
56	  getStats: () => api.get('/admin/stats'),
57	  getMessages: () => api.get('/admin/messages'),
58	  moderateMessage: (id) => api.post(`/admin/messages/${id}/moderate`),
59	  deleteMessage: (id) => api.delete(`/admin/messages/${id}`),
60	};
61	
62	export default api;
63	
64	