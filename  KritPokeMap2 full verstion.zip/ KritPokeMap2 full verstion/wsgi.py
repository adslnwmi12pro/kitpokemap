from src.main import create_app

# Create the application instance
app = create_app()

if __name__ == "__main__":
    # This block is for local development only and will be ignored by Gunicorn
    app.run(host='0.0.0.0', port=8080)

