# KritPokeMap UX/UI Design and Wireframe

## 1. Design Principles

*   **Theme:** Pokémon-inspired (Yellow, Black, Gray, Blue).
*   **Font:** Sukhumvit (for Thai text) for a modern and clean look.
*   **Language:** Dual language support (English/Thai).
*   **Focus:** Map-centric, clean, and intuitive for quick information access.

## 2. Color Palette

| Color | Hex Code | Usage |
| :--- | :--- | :--- |
| **Primary Yellow** | `#FFCB05` | Main branding, Call-to-Action (CTA) buttons, Pokémon marker highlights. |
| **Secondary Blue** | `#3D7DCA` | Navigation bar, links, map features (e.g., Water-type Pokémon markers). |
| **Accent Black** | `#2A75BB` | Text, borders, shadows, dark mode elements. |
| **Neutral Gray** | `#A6A6A6` | Backgrounds, secondary text, disabled elements. |
| **Background White** | `#FFFFFF` | Main content area, map background. |

## 3. Wireframe & Layout

### A. Landing Page (Pre-Login)

*   **Header:** Logo ("KritPokeMap"), Language Switcher (EN/TH), "Login" button, "Subscribe" button.
*   **Hero Section:** Catchy tagline (e.g., "Catch 'Em All in Kanchanaburi!"), brief explanation of the service (Crowdsourced Pokémon Map), large CTA button ("Start Your Adventure - Subscribe Now").
*   **Features Section:** Icons and short descriptions of key features (Real-time Map, Monthly Subscription, Live Chat, Admin Verified).

### B. Main Map View (Post-Login)

*   **Layout:** Map occupies the majority of the screen (approx. 75-80%).
*   **Header (Top):** Logo, User Profile (Avatar/Name), "Report Sighting" button, "Logout" button.
*   **Sidebar (Left/Right):**
    *   **Filter Panel:** Checkboxes/Toggles to filter Pokémon by Type, Rarity, or Time Remaining.
    *   **Live Feed/Chat Panel:** Real-time comment section for news, announcements, and user communication.
*   **Map:**
    *   **Kanchanaburi Focus:** Default view centered on Kanchanaburi province.
    *   **Pokémon Markers:** Custom markers (Poké Ball icon or Pokémon sprite) indicating location. Clicking a marker opens a pop-up with details (Pokémon Name, Type, Time Reported, Reported By).
    *   **"Report Sighting" Tool:** A button/icon that, when clicked, allows the user to drop a pin on the map and fill out a form (Pokémon name, time found).

### C. User Dashboard/Subscription Management

*   **Sections:**
    *   **Profile:** User details, change password.
    *   **Subscription:** Current plan (Monthly), Next billing date, "Manage Subscription" (link to payment portal).
    *   **Activity Log:** History of reported sightings and chat messages.

### D. Admin Dashboard (Separate View)

*   **User Management:** List of all users, ability to view profile, suspend, or delete accounts.
*   **Subscription Overview:** Total active subscribers, monthly recurring revenue (MRR).
*   **Content Moderation:** List of all reported sightings and chat messages with options to approve/delete/hide.

## 4. Database Schema Design

The database will use **PostgreSQL** with the **PostGIS** extension for efficient geospatial queries.

### Table: `users`

| Column | Data Type | Description |
| :--- | :--- | :--- |
| `id` | SERIAL PRIMARY KEY | Unique user ID. |
| `username` | VARCHAR(50) UNIQUE | Username for login. |
| `email` | VARCHAR(100) UNIQUE | User email. |
| `password_hash` | VARCHAR(255) | Hashed password. |
| `role` | ENUM ('user', 'admin') | User role (default 'user'). |
| `created_at` | TIMESTAMP WITH TIME ZONE | Registration date. |
| `is_active` | BOOLEAN | Account status (for admin suspension). |

### Table: `subscriptions`

| Column | Data Type | Description |
| :--- | :--- | :--- |
| `id` | SERIAL PRIMARY KEY | Unique subscription ID. |
| `user_id` | INTEGER FOREIGN KEY | Links to `users.id`. |
| `plan_name` | VARCHAR(50) | e.g., 'Monthly Access'. |
| `status` | ENUM ('active', 'inactive', 'pending') | Subscription status. |
| `start_date` | DATE | Date subscription started. |
| `end_date` | DATE | Date subscription ends (for non-recurring or trial). |
| `stripe_customer_id` | VARCHAR(255) | ID from payment gateway. |

### Table: `pokemon_sightings` (Crowdsourced Data)

| Column | Data Type | Description |
| :--- | :--- | :--- |
| `id` | SERIAL PRIMARY KEY | Unique sighting ID. |
| `reporter_id` | INTEGER FOREIGN KEY | Links to `users.id`. |
| `pokemon_name` | VARCHAR(50) | Name of the Pokémon reported. |
| `location` | GEOMETRY(Point, 4326) | **PostGIS Point** data type for latitude/longitude. |
| `time_reported` | TIMESTAMP WITH TIME ZONE | Time the sighting was reported. |
| `time_found` | TIMESTAMP WITH TIME ZONE | Time the Pokémon was actually found (optional). |
| `is_verified` | BOOLEAN | Admin or community verification status. |
| `is_active` | BOOLEAN | Sighting is currently displayed (e.g., active for 1 hour). |

### Table: `chat_messages` (Real-time Communication)

| Column | Data Type | Description | |
| :--- | :--- | :--- | :--- |
| `id` | SERIAL PRIMARY KEY | Unique message ID. |
| `user_id` | INTEGER FOREIGN KEY | Links to `users.id`. |
| `message_text` | TEXT | The content of the message. |
| `timestamp` | TIMESTAMP WITH TIME ZONE | Time the message was sent. |
| `is_moderated` | BOOLEAN | Admin moderation status. |
| `is_announcement` | BOOLEAN | Flag for admin announcements. |

## 5. Next Step

Proceed to **Phase 4: พัฒนาระบบ Backend API และฐานข้อมูล** using the defined schema and technology stack (FastAPI/PostgreSQL/PostGIS).
