Text file: admin.py
Latest content with line numbers:
1	from flask import Blueprint, request, jsonify
2	from src.models.user import db, User, Subscription, PokemonSighting, ChatMessage
3	from src.utils.auth import admin_required
4	from datetime import datetime
5	
6	admin_bp = Blueprint('admin', __name__)
7	
8	@admin_bp.route('/users', methods=['GET'])
9	@admin_required
10	def get_all_users(current_user):
11	    """Get all users (admin only)"""
12	    users = User.query.all()
13	    return jsonify({
14	        'users': [user.to_dict() for user in users]
15	    }), 200
16	
17	@admin_bp.route('/users/<int:user_id>', methods=['GET'])
18	@admin_required
19	def get_user(current_user, user_id):
20	    """Get a specific user by ID (admin only)"""
21	    user = User.query.get(user_id)
22	    
23	    if not user:
24	        return jsonify({'error': 'User not found'}), 404
25	    
26	    # Get user's subscription
27	    subscription = Subscription.query.filter_by(user_id=user_id, status='active').first()
28	    
29	    # Get user's sightings count
30	    sightings_count = PokemonSighting.query.filter_by(reporter_id=user_id).count()
31	    
32	    # Get user's messages count
33	    messages_count = ChatMessage.query.filter_by(user_id=user_id).count()
34	    
35	    return jsonify({
36	        'user': user.to_dict(),
37	        'subscription': subscription.to_dict() if subscription else None,
38	        'sightings_count': sightings_count,
39	        'messages_count': messages_count
40	    }), 200
41	
42	@admin_bp.route('/users/<int:user_id>/suspend', methods=['POST'])
43	@admin_required
44	def suspend_user(current_user, user_id):
45	    """Suspend a user account (admin only)"""
46	    user = User.query.get(user_id)
47	    
48	    if not user:
49	        return jsonify({'error': 'User not found'}), 404
50	    
51	    if user.role == 'admin':
52	        return jsonify({'error': 'Cannot suspend admin users'}), 403
53	    
54	    user.is_active = False
55	    
56	    try:
57	        db.session.commit()
58	        return jsonify({'message': f'User {user.username} suspended successfully'}), 200
59	    except Exception as e:
60	        db.session.rollback()
61	        return jsonify({'error': str(e)}), 500
62	
63	@admin_bp.route('/users/<int:user_id>/activate', methods=['POST'])
64	@admin_required
65	def activate_user(current_user, user_id):
66	    """Activate a suspended user account (admin only)"""
67	    user = User.query.get(user_id)
68	    
69	    if not user:
70	        return jsonify({'error': 'User not found'}), 404
71	    
72	    user.is_active = True
73	    
74	    try:
75	        db.session.commit()
76	        return jsonify({'message': f'User {user.username} activated successfully'}), 200
77	    except Exception as e:
78	        db.session.rollback()
79	        return jsonify({'error': str(e)}), 500
80	
81	@admin_bp.route('/users/<int:user_id>', methods=['DELETE'])
82	@admin_required
83	def delete_user(current_user, user_id):
84	    """Delete a user account (admin only)"""
85	    user = User.query.get(user_id)
86	    
87	    if not user:
88	        return jsonify({'error': 'User not found'}), 404
89	    
90	    if user.role == 'admin':
91	        return jsonify({'error': 'Cannot delete admin users'}), 403
92	    
93	    try:
94	        db.session.delete(user)
95	        db.session.commit()
96	        return jsonify({'message': f'User {user.username} deleted successfully'}), 200
97	    except Exception as e:
98	        db.session.rollback()
99	        return jsonify({'error': str(e)}), 500
100	
101	@admin_bp.route('/subscriptions', methods=['GET'])
102	@admin_required
103	def get_all_subscriptions(current_user):
104	    """Get all subscriptions (admin only)"""
105	    subscriptions = Subscription.query.all()
106	    return jsonify({
107	        'subscriptions': [sub.to_dict() for sub in subscriptions]
108	    }), 200
109	
110	@admin_bp.route('/stats', methods=['GET'])
111	@admin_required
112	def get_stats(current_user):
113	    """Get platform statistics (admin only)"""
114	    total_users = User.query.count()
115	    active_users = User.query.filter_by(is_active=True).count()
116	    total_subscriptions = Subscription.query.filter_by(status='active').count()
117	    total_sightings = PokemonSighting.query.count()
118	    active_sightings = PokemonSighting.query.filter_by(is_active=True).count()
119	    verified_sightings = PokemonSighting.query.filter_by(is_verified=True).count()
120	    total_messages = ChatMessage.query.count()
121	    
122	    return jsonify({
123	        'stats': {
124	            'total_users': total_users,
125	            'active_users': active_users,
126	            'total_subscriptions': total_subscriptions,
127	            'total_sightings': total_sightings,
128	            'active_sightings': active_sightings,
129	            'verified_sightings': verified_sightings,
130	            'total_messages': total_messages
131	        }
132	    }), 200
133	
134	@admin_bp.route('/messages', methods=['GET'])
135	@admin_required
136	def get_all_messages(current_user):
137	    """Get all chat messages (admin only)"""
138	    messages = ChatMessage.query.order_by(ChatMessage.timestamp.desc()).limit(100).all()
139	    return jsonify({
140	        'messages': [msg.to_dict() for msg in messages]
141	    }), 200
142	
143	@admin_bp.route('/messages/<int:message_id>/moderate', methods=['POST'])
144	@admin_required
145	def moderate_message(current_user, message_id):
146	    """Moderate a chat message (admin only)"""
147	    message = ChatMessage.query.get(message_id)
148	    
149	    if not message:
150	        return jsonify({'error': 'Message not found'}), 404
151	    
152	    message.is_moderated = True
153	    
154	    try:
155	        db.session.commit()
156	        return jsonify({'message': 'Message moderated successfully'}), 200
157	    except Exception as e:
158	        db.session.rollback()
159	        return jsonify({'error': str(e)}), 500
160	
161	@admin_bp.route('/messages/<int:message_id>', methods=['DELETE'])
162	@admin_required
163	def delete_message(current_user, message_id):
164	    """Delete a chat message (admin only)"""
165	    message = ChatMessage.query.get(message_id)
166	    
167	    if not message:
168	        return jsonify({'error': 'Message not found'}), 404
169	    
170	    try:
171	        db.session.delete(message)
172	        db.session.commit()
173	        return jsonify({'message': 'Message deleted successfully'}), 200
174	    except Exception as e:
175	        db.session.rollback()
176	        return jsonify({'error': str(e)}), 500
177	
178	