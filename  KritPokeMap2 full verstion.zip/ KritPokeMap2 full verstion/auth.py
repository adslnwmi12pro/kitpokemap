Text file: auth.py
Latest content with line numbers:
1	from flask import Blueprint, request, jsonify
2	from src.models.user import db, User, Subscription
3	from src.utils.auth import generate_token, token_required
4	from datetime import datetime, timedelta
5	
6	auth_bp = Blueprint('auth', __name__)
7	
8	@auth_bp.route('/register', methods=['POST'])
9	def register():
10	    """Register a new user"""
11	    data = request.get_json()
12	    
13	    # Validate input
14	    if not data or not data.get('username') or not data.get('email') or not data.get('password'):
15	        return jsonify({'error': 'Username, email, and password are required'}), 400
16	    
17	    # Check if user already exists
18	    if User.query.filter_by(username=data['username']).first():
19	        return jsonify({'error': 'Username already exists'}), 400
20	    
21	    if User.query.filter_by(email=data['email']).first():
22	        return jsonify({'error': 'Email already exists'}), 400
23	    
24	    # Create new user
25	    new_user = User(
26	        username=data['username'],
27	        email=data['email'],
28	        role=data.get('role', 'user')
29	    )
30	    new_user.set_password(data['password'])
31	    
32	    try:
33	        db.session.add(new_user)
34	        db.session.commit()
35	        
36	        # Create a trial subscription (7 days)
37	        trial_subscription = Subscription(
38	            user_id=new_user.id,
39	            plan_name='Trial',
40	            status='active',
41	            start_date=datetime.utcnow().date(),
42	            end_date=(datetime.utcnow() + timedelta(days=7)).date()
43	        )
44	        db.session.add(trial_subscription)
45	        db.session.commit()
46	        
47	        # Generate token
48	        token = generate_token(new_user.id, new_user.role)
49	        
50	        return jsonify({
51	            'message': 'User registered successfully',
52	            'user': new_user.to_dict(),
53	            'token': token
54	        }), 201
55	    except Exception as e:
56	        db.session.rollback()
57	        return jsonify({'error': str(e)}), 500
58	
59	@auth_bp.route('/login', methods=['POST'])
60	def login():
61	    """Login user"""
62	    data = request.get_json()
63	    
64	    if not data or not data.get('username') or not data.get('password'):
65	        return jsonify({'error': 'Username and password are required'}), 400
66	    
67	    # Find user
68	    user = User.query.filter_by(username=data['username']).first()
69	    
70	    if not user or not user.check_password(data['password']):
71	        return jsonify({'error': 'Invalid username or password'}), 401
72	    
73	    if not user.is_active:
74	        return jsonify({'error': 'Account is inactive'}), 403
75	    
76	    # Generate token
77	    token = generate_token(user.id, user.role)
78	    
79	    return jsonify({
80	        'message': 'Login successful',
81	        'user': user.to_dict(),
82	        'token': token
83	    }), 200
84	
85	@auth_bp.route('/me', methods=['GET'])
86	@token_required
87	def get_current_user(current_user):
88	    """Get current user information"""
89	    return jsonify({
90	        'user': current_user.to_dict()
91	    }), 200
92	
93	@auth_bp.route('/change-password', methods=['POST'])
94	@token_required
95	def change_password(current_user):
96	    """Change user password"""
97	    data = request.get_json()
98	    
99	    if not data or not data.get('old_password') or not data.get('new_password'):
100	        return jsonify({'error': 'Old password and new password are required'}), 400
101	    
102	    if not current_user.check_password(data['old_password']):
103	        return jsonify({'error': 'Old password is incorrect'}), 401
104	    
105	    current_user.set_password(data['new_password'])
106	    
107	    try:
108	        db.session.commit()
109	        return jsonify({'message': 'Password changed successfully'}), 200
110	    except Exception as e:
111	        db.session.rollback()
112	        return jsonify({'error': str(e)}), 500
113	
114	