Text file: AdminDashboard.jsx
Latest content with line numbers:
1	import { useState, useEffect } from 'react';
2	import { Link } from 'react-router-dom';
3	import { Button } from '@/components/ui/button';
4	import { MapPin, LogOut, Users, MessageCircle, MapPinned, TrendingUp } from 'lucide-react';
5	import { adminAPI } from '@/lib/api';
6	
7	export default function AdminDashboard({ user, onLogout }) {
8	  const [stats, setStats] = useState(null);
9	  const [users, setUsers] = useState([]);
10	  const [loading, setLoading] = useState(true);
11	
12	  useEffect(() => {
13	    fetchData();
14	  }, []);
15	
16	  const fetchData = async () => {
17	    try {
18	      const [statsRes, usersRes] = await Promise.all([
19	        adminAPI.getStats(),
20	        adminAPI.getUsers(),
21	      ]);
22	      
23	      setStats(statsRes.data.stats);
24	      setUsers(usersRes.data.users);
25	    } catch (error) {
26	      console.error('Error fetching admin data:', error);
27	    } finally {
28	      setLoading(false);
29	    }
30	  };
31	
32	  const handleSuspendUser = async (userId) => {
33	    if (!confirm('Are you sure you want to suspend this user?')) return;
34	    
35	    try {
36	      await adminAPI.suspendUser(userId);
37	      fetchData();
38	      alert('User suspended successfully');
39	    } catch (error) {
40	      alert('Failed to suspend user');
41	    }
42	  };
43	
44	  const handleActivateUser = async (userId) => {
45	    try {
46	      await adminAPI.activateUser(userId);
47	      fetchData();
48	      alert('User activated successfully');
49	    } catch (error) {
50	      alert('Failed to activate user');
51	    }
52	  };
53	
54	  if (loading) {
55	    return <div className="flex items-center justify-center h-screen">Loading...</div>;
56	  }
57	
58	  return (
59	    <div className="min-h-screen bg-gray-50">
60	      {/* Header */}
61	      <header className="bg-white border-b shadow-sm">
62	        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
63	          <div className="flex items-center gap-3">
64	            <div className="w-10 h-10 rounded-full flex items-center justify-center" 
65	                 style={{ backgroundColor: 'var(--pokemon-yellow)' }}>
66	              <MapPin className="w-6 h-6" style={{ color: 'var(--pokemon-black)' }} />
67	            </div>
68	            <div>
69	              <h1 className="text-xl font-bold">Admin Dashboard</h1>
70	              <p className="text-xs text-gray-600">KritPokeMap</p>
71	            </div>
72	          </div>
73	
74	          <div className="flex items-center gap-3">
75	            <Link to="/map">
76	              <Button variant="outline">Back to Map</Button>
77	            </Link>
78	            <Button variant="outline" onClick={onLogout}>
79	              <LogOut className="w-4 h-4 mr-2" />
80	              Logout
81	            </Button>
82	          </div>
83	        </div>
84	      </header>
85	
86	      {/* Main Content */}
87	      <div className="container mx-auto px-4 py-8">
88	        {/* Stats Cards */}
89	        <div className="grid md:grid-cols-4 gap-6 mb-8">
90	          <div className="bg-white p-6 rounded-lg shadow">
91	            <div className="flex items-center gap-3 mb-2">
92	              <Users className="w-8 h-8" style={{ color: 'var(--pokemon-blue)' }} />
93	              <div>
94	                <p className="text-sm text-gray-600">Total Users</p>
95	                <p className="text-2xl font-bold">{stats?.total_users || 0}</p>
96	              </div>
97	            </div>
98	          </div>
99	
100	          <div className="bg-white p-6 rounded-lg shadow">
101	            <div className="flex items-center gap-3 mb-2">
102	              <TrendingUp className="w-8 h-8" style={{ color: 'var(--pokemon-yellow)' }} />
103	              <div>
104	                <p className="text-sm text-gray-600">Active Subscriptions</p>
105	                <p className="text-2xl font-bold">{stats?.total_subscriptions || 0}</p>
106	              </div>
107	            </div>
108	          </div>
109	
110	          <div className="bg-white p-6 rounded-lg shadow">
111	            <div className="flex items-center gap-3 mb-2">
112	              <MapPinned className="w-8 h-8 text-green-600" />
113	              <div>
114	                <p className="text-sm text-gray-600">Active Sightings</p>
115	                <p className="text-2xl font-bold">{stats?.active_sightings || 0}</p>
116	              </div>
117	            </div>
118	          </div>
119	
120	          <div className="bg-white p-6 rounded-lg shadow">
121	            <div className="flex items-center gap-3 mb-2">
122	              <MessageCircle className="w-8 h-8 text-purple-600" />
123	              <div>
124	                <p className="text-sm text-gray-600">Total Messages</p>
125	                <p className="text-2xl font-bold">{stats?.total_messages || 0}</p>
126	              </div>
127	            </div>
128	          </div>
129	        </div>
130	
131	        {/* Users Table */}
132	        <div className="bg-white rounded-lg shadow">
133	          <div className="p-6 border-b">
134	            <h2 className="text-xl font-bold">User Management</h2>
135	          </div>
136	          <div className="overflow-x-auto">
137	            <table className="w-full">
138	              <thead className="bg-gray-50">
139	                <tr>
140	                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
141	                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Username</th>
142	                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
143	                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Role</th>
144	                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
145	                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
146	                </tr>
147	              </thead>
148	              <tbody className="divide-y divide-gray-200">
149	                {users.map((u) => (
150	                  <tr key={u.id}>
151	                    <td className="px-6 py-4 text-sm">{u.id}</td>
152	                    <td className="px-6 py-4 text-sm font-medium">{u.username}</td>
153	                    <td className="px-6 py-4 text-sm">{u.email}</td>
154	                    <td className="px-6 py-4 text-sm">
155	                      <span className={`px-2 py-1 rounded text-xs ${
156	                        u.role === 'admin' ? 'bg-purple-100 text-purple-700' : 'bg-gray-100 text-gray-700'
157	                      }`}>
158	                        {u.role}
159	                      </span>
160	                    </td>
161	                    <td className="px-6 py-4 text-sm">
162	                      <span className={`px-2 py-1 rounded text-xs ${
163	                        u.is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
164	                      }`}>
165	                        {u.is_active ? 'Active' : 'Suspended'}
166	                      </span>
167	                    </td>
168	                    <td className="px-6 py-4 text-sm">
169	                      {u.role !== 'admin' && (
170	                        <div className="flex gap-2">
171	                          {u.is_active ? (
172	                            <Button
173	                              size="sm"
174	                              variant="outline"
175	                              onClick={() => handleSuspendUser(u.id)}
176	                            >
177	                              Suspend
178	                            </Button>
179	                          ) : (
180	                            <Button
181	                              size="sm"
182	                              variant="outline"
183	                              onClick={() => handleActivateUser(u.id)}
184	                            >
185	                              Activate
186	                            </Button>
187	                          )}
188	                        </div>
189	                      )}
190	                    </td>
191	                  </tr>
192	                ))}
193	              </tbody>
194	            </table>
195	          </div>
196	        </div>
197	      </div>
198	    </div>
199	  );
200	}
201	
202	